﻿using System;

public class Movie
{
	private string _name;
	private string _rating;
	private int _runningTime;
	private string _director;

	public Movie(string name, string rating, int runningTime, string director)
	{
		_name = name;
		_rating = ValidateRating(rating);
		_runningTime = runningTime;
		_director = director;
	}

	public string Name => _name;

	public string Director => _director;

	public string Rating => _rating;

	public string RunningTime
	{
		get
		{
			int hours = _runningTime / 60;
			int minutes = _runningTime % 60;
			return $"{hours} hours {minutes} minutes";
		}
	}

	public void SetRating(string rating)
	{
		_rating = ValidateRating(rating);
	}

	public void SetRunningTime(int runningTime)
	{
		_runningTime = runningTime;
	}

	public string ToString()
	{
		return $"Name: {_name}, Rating: {_rating}, Running Time: {RunningTime}, Director: {_director}";
	}

	private string ValidateRating(string rating)
	{
		string[] validRatings = { "G", "PG", "PG-13", "R", "NC_17" };
		if (Array.Exists(validRatings, element => element == rating))
		{
			return rating;
		}
		else
		{
			return "NC_17";
		}
	}
}

class TestMovieMethods
{
	public static void Main(string[] args)
	{
		// Creating instances of Movie class
		Movie movie1 = new Movie("Inception", "PG-13", 148, "Christopher Nolan");
		Movie movie2 = new Movie("The Godfather", "R", 175, "Francis Ford Coppola");
		Movie movie3 = new Movie("The Shawshank Redemption", "PG", 142, "Frank Darabont");

		// Outputting details of movies
		Console.WriteLine(movie1.ToString());
		Console.WriteLine(movie2.ToString());
		Console.WriteLine(movie3.ToString());

		// Demonstrating exception handling for invalid rating
		try
		{
			movie1.SetRating("XYZ");
		}
		catch (Exception ex)
		{
			Console.WriteLine("Invalid rating provided. Setting rating to default (NC_17).");
			movie1.SetRating("NC_17");
		}
		Console.WriteLine(movie1.ToString());
	}
}
