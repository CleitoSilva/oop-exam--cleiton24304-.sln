﻿//1.A class named BuildingCodes with the following properties: 
//Building Id, Building Location,
//Building Code. Building Id is a numeric field. Building Code is alphanumeric and is between 4 and 6 characters long. Building Location is a string – maximum length is 20 characters. All fields are required

using System;

public class BuildingCodes
{
	public int BuildingId { get; set; }
	public string BuildingLocation { get; set; }
	public string BuildingCode { get; set; }

	public BuildingCodes(int buildingId, string buildingLocation, string buildingCode)
	{
		BuildingId = buildingId;
		BuildingLocation = buildingLocation;
		BuildingCode = buildingCode;
	}

	public bool Validate()
	{
		if (!int.TryParse(BuildingId.ToString(), out _))
		{
			Console.WriteLine("Building Id must be numeric.");
			return false;
		}
		if (BuildingLocation.Length > 20)
		{
			Console.WriteLine("Building Location must be a string with maximum length of 20 characters.");
			return false;
		}
		if (BuildingCode.Length < 4 || BuildingCode.Length > 6 || !IsAlphaNumeric(BuildingCode))
		{
			Console.WriteLine("Building Code must be alphanumeric and between 4 and 6 characters long.");
			return false;
		}
		return true;
	}

	private bool IsAlphaNumeric(string str)
	{
		foreach (char c in str)
		{
			if (!char.IsLetterOrDigit(c))
				return false;
		}
		return true;
	}
}

class Program
{
	static void Main(string[] args)
	{
		BuildingCodes building = new BuildingCodes(1, "New York", "ABC123");
		if (building.Validate())
		{
			Console.WriteLine("Building information is valid.");
		}
		else
		{
			Console.WriteLine("Validation failed.");
		}
	}
}
