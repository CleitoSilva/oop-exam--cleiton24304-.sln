﻿using System;
using System.Collections.Generic;

namespace BuildingCodeProgram
{
	// Class representing building codes
	class BuildingCodes
	{
		public int BuildingId { get; set; }
		public string BuildingLocation { get; set; }
		public string BuildingCode { get; set; }

		// Constructor
		public BuildingCodes(int id, string location, string code)
		{
			BuildingId = id;
			BuildingLocation = location;
			BuildingCode = code;
		}
	}

	class Program
	{
		static List<BuildingCodes> buildingList = new List<BuildingCodes>();

		static void Main(string[] args)
		{
	
			InitializeData();

			while (true)
			{
				Console.WriteLine("\nChoose an option:");
				Console.WriteLine("1. List buildings in ascending order");
				Console.WriteLine("2. List buildings in descending order");
				Console.WriteLine("3. Add new building data");
				Console.WriteLine("4. Exit");

				// Read user choice
				string choice = Console.ReadLine();

				switch (choice)
				{
					case "1":
						ListBuildings(true); 
						break;
					case "2":
						ListBuildings(false); 
						break;
					case "3":
						AddBuildingData();
						break;
					case "4":
						Environment.Exit(0);
						break;
					default:
						Console.WriteLine("Invalid choice! Please enter a valid option.");
						break;
				}
			}
		}

		// Method to initialize data with 10 mock examples
		static void InitializeData()
		{
			// Generating mock data for demonstration
			for (int i = 1; i <= 10; i++)
			{
				// Using a NuGet package for faking data is recommended, but for simplicity, I'll generate basic mock data here
				buildingList.Add(new BuildingCodes(i, $"Location{i}", $"Code{i}"));
			}
		}

		// Method to list buildings in ascending or descending order based on BuildingId
		static void ListBuildings(bool ascending)
		{
			// Sorting the list based on BuildingId
			if (ascending)
				buildingList.Sort((x, y) => x.BuildingId.CompareTo(y.BuildingId));
			else
				buildingList.Sort((x, y) => y.BuildingId.CompareTo(x.BuildingId));

			// Displaying the sorted list
			Console.WriteLine("\nBuilding List:");
			foreach (var building in buildingList)
			{
				Console.WriteLine($"Building Id: {building.BuildingId}, Location: {building.BuildingLocation}, Code: {building.BuildingCode}");
			}
		}

		// Method to add new building data
		static void AddBuildingData()
		{
			Console.WriteLine("\nEnter Building Id:");
			int id = int.Parse(Console.ReadLine());

			Console.WriteLine("Enter Building Location:");
			string location = Console.ReadLine();

			Console.WriteLine("Enter Building Code:");
			string code = Console.ReadLine();

			// Add the new building to the list
			buildingList.Add(new BuildingCodes(id, location, code));

			// List all buildings in ascending order after adding the new building
			ListBuildings(true);
		}
	}
}
